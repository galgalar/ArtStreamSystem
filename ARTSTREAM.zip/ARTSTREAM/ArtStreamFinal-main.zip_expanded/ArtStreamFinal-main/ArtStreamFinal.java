
import javax.swing.*;
public class ArtStreamFinal {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(()->{
         new FirstFrame();
      });
    }
}
