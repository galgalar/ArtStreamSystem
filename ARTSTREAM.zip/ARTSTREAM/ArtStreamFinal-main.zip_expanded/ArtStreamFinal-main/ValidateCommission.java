public interface ValidateCommission {

    boolean validateEmail(String email);
    boolean validateContact();
    boolean isEmpty();


}
