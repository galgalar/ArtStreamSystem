import java.awt.Color;

import javax.swing.*;
public class Accepted extends JPanel {
    public Accepted()
    {
        setBackground(Color.red);
        setVisible(true);
    }

}
