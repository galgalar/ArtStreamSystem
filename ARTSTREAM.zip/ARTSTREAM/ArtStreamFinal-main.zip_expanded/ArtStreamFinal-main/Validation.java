public interface Validation {

    public boolean validateLogin(String name, String pass);
    public boolean validateRegister(String name, String pass);
    
}
