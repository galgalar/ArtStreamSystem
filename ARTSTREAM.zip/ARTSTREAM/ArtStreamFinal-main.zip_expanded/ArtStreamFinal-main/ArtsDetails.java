public interface ArtsDetails {

    
    

}
