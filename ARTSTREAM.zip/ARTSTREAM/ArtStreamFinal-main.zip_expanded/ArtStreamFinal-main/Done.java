import java.awt.Color;

import javax.swing.*;
public class Done extends JPanel {
    public Done()
    {
        setBackground(Color.blue);
        setVisible(true);
    }

}
